// JavaScript Document
(function() {
	"use strict";
//variables
//functions
//listeners 	
})();